/*
  CraftAura by Pooja - Google Apps Script backend

  1. Create/open your Google Sheet.
  2. Keep the product sheet named "Products" with these exact headers:
     Product ID | Product Name | Category | Price | Description | Stock |
     Photo 1 | Photo 2 | Photo 3 | Video | Active.
  3. Extensions -> Apps Script.
  4. Paste this code.
  5. Replace SPREADSHEET_ID below with your Google Sheet ID.
  6. Deploy -> New deployment -> Web app.
     Execute as: Me
     Who has access: Anyone
  7. Copy the /exec URL into js/config.js.

  IMPORTANT:
  - Product images/videos can be Google Drive sharing links.
  - Make the relevant Drive files accessible to anyone with the link.
  - The Orders sheet is created automatically.
*/

const SPREADSHEET_ID = "PASTE_YOUR_GOOGLE_SHEET_ID_HERE";
const PRODUCT_SHEET_NAME = "Products";
const ORDER_SHEET_NAME = "Orders";

function doGet(e) {
  try {
    const action = (e && e.parameter && e.parameter.action) || "products";
    if (action === "products") {
      return jsonOutput({ success: true, products: getProducts_() });
    }
    return jsonOutput({ success: false, message: "Unknown action." });
  } catch (err) {
    return jsonOutput({ success: false, message: err.message });
  }
}

function doPost(e) {
  try {
    const raw = e && e.parameter && e.parameter.payload;
    if (!raw) throw new Error("Missing order data.");

    const payload = JSON.parse(raw);
    if (payload.action !== "order") throw new Error("Invalid request.");

    const result = createOrder_(payload);
    return jsonOutput(result);
  } catch (err) {
    return jsonOutput({ success: false, message: err.message });
  }
}

function getProducts_() {
  const sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(PRODUCT_SHEET_NAME);
  if (!sheet) throw new Error('Sheet "' + PRODUCT_SHEET_NAME + '" not found.');

  const values = sheet.getDataRange().getDisplayValues();
  if (values.length < 2) return [];

  const headers = values[0].map(h => String(h).trim());
  return values.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);

    // Accept "Active." exactly as requested, and also "Active" as a fallback.
    const active = obj["Active."] !== undefined ? obj["Active."] : obj["Active"];
    const isActive = String(active || "").trim().toLowerCase();

    return {
      id: obj["Product ID"] || "",
      name: obj["Product Name"] || "",
      category: obj["Category"] || "",
      price: Number(String(obj["Price"] || "0").replace(/,/g, "")) || 0,
      description: obj["Description"] || "",
      stock: Number(String(obj["Stock"] || "0").replace(/,/g, "")) || 0,
      photo1: obj["Photo 1"] || "",
      photo2: obj["Photo 2"] || "",
      photo3: obj["Photo 3"] || "",
      video: obj["Video"] || "",
      active: isActive === "yes" || isActive === "true" || isActive === "1"
    };
  }).filter(p => p.id && p.active);
}

function createOrder_(payload) {
  const customer = payload.customer || {};
  const items = payload.items || [];
  if (!customer.name || !customer.mobile || !customer.address || !customer.city || !customer.pincode) {
    throw new Error("Please fill all required customer details.");
  }
  if (!items.length) throw new Error("Cart is empty.");

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);

  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    const productSheet = ss.getSheetByName(PRODUCT_SHEET_NAME);
    if (!productSheet) throw new Error('Sheet "' + PRODUCT_SHEET_NAME + '" not found.');

    const products = getProducts_();
    let total = 0;
    const checkedItems = [];

    items.forEach(item => {
      const p = products.find(x => String(x.id) === String(item.productId));
      if (!p) throw new Error("Product " + item.productId + " is no longer available.");

      const qty = Number(item.qty);
      if (!Number.isInteger(qty) || qty < 1) throw new Error("Invalid quantity.");
      if (qty > p.stock) throw new Error(p.name + " has only " + p.stock + " item(s) available.");

      const price = Number(p.price);
      total += price * qty;
      checkedItems.push({
        id: p.id,
        name: p.name,
        price: price,
        qty: qty
      });
    });

    const orderId = "CA" + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyyMMddHHmmss");
    const orderSheet = getOrCreateOrderSheet_(ss);

    const productSummary = checkedItems.map(i => i.id + " - " + i.name + " × " + i.qty).join("\n");
    const qtySummary = checkedItems.map(i => i.qty).join(", ");
    const priceSummary = checkedItems.map(i => i.price).join(", ");

    orderSheet.appendRow([
      orderId,
      new Date(),
      customer.name,
      customer.mobile,
      customer.whatsapp || "",
      customer.address,
      customer.city,
      customer.pincode,
      productSummary,
      qtySummary,
      priceSummary,
      total,
      "COD",
      customer.note || "",
      "New"
    ]);

    // Reduce stock after successful order.
    reduceStock_(productSheet, checkedItems);

    return {
      success: true,
      orderId: orderId,
      total: total
    };
  } finally {
    lock.releaseLock();
  }
}

function getOrCreateOrderSheet_(ss) {
  let sheet = ss.getSheetByName(ORDER_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(ORDER_SHEET_NAME);
    sheet.appendRow([
      "Order ID",
      "Date/Time",
      "Customer Name",
      "Mobile",
      "WhatsApp",
      "Address",
      "City",
      "PIN Code",
      "Products",
      "Quantities",
      "Prices",
      "Total",
      "Payment",
      "Order Note",
      "Status"
    ]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function reduceStock_(sheet, items) {
  const data = sheet.getDataRange().getValues();
  const headers = data[0].map(h => String(h).trim());
  const idCol = headers.indexOf("Product ID");
  const stockCol = headers.indexOf("Stock");

  if (idCol < 0 || stockCol < 0) throw new Error("Product ID or Stock column missing.");

  const stockUpdates = {};
  items.forEach(item => {
    stockUpdates[String(item.id)] = (stockUpdates[String(item.id)] || 0) + item.qty;
  });

  for (let r = 1; r < data.length; r++) {
    const id = String(data[r][idCol]);
    if (stockUpdates[id] !== undefined) {
      const oldStock = Number(data[r][stockCol]) || 0;
      data[r][stockCol] = Math.max(0, oldStock - stockUpdates[id]);
    }
  }

  sheet.getRange(1, 1, data.length, data[0].length).setValues(data);
}

function jsonOutput(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
